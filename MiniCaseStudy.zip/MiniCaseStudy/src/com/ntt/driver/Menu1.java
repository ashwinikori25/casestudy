package com.ntt.driver;

import java.util.Scanner;

public class Menu1 {

	public static void main(String[] args) {
		System.out.println("**Welcome to vechile rent application**");
		System.out.println("*********Menu**********");
		
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter ur choice: 1.Admin\n 2.Customer\n");
			int choice = sc.nextInt();
			
			switch(choice)
			{
				case 1 : System.out.println("Enter the user id: ");
				         int id = sc.nextInt();
				         System.out.println("Enter the password: ");
				         String password = sc.nextLine();
				         if(id == 12345 && password.equals("NTTDATA"))
				         {
				        	 System.out.println("***Welcome Admin***");
				         }
				         else
				         {
				        	 System.out.println(" user name password mismatched ");
				        	 break;
				         }
				case 2 : System.out.println("Enter user id: ");
				         int id1 = sc.nextInt();
				         System.out.println("Enter customer name: ");
				         String cust_name = sc.nextLine();
				         System.out.println("Enter the customer password: ");
				         String cust_password = sc.nextLine();
				         System.out.println("Enter the customer city: ");
				         String city = sc.nextLine();
				         System.out.println("Enter the customer email id: ");
				         String email_id = sc.nextLine();
				         System.out.println("Enter the customer contact no: ");
				         int contact_no = sc.nextInt();
				         System.out.println("Enter the customer role id: ");
				         int role_id = sc.nextInt();
			}
		}
	}
}
